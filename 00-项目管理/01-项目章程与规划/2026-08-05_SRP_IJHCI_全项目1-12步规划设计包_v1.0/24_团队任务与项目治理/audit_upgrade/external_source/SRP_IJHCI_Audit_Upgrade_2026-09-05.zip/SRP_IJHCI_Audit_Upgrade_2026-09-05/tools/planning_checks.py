"""Exact planning arithmetic; not project power, empirical OPE or runtime testing."""
from __future__ import annotations
import argparse
import itertools
import json
from fractions import Fraction
from pathlib import Path

def checks() -> dict:
    paths = []
    for permutation in itertools.permutations(range(4)):
        remaining = list(range(4))
        p = Fraction(1)
        for chosen in permutation:
            # Illustrative fixed preference, not the user's learned policy.
            greedy = min(remaining)
            p *= Fraction(1, 5 * len(remaining)) + (Fraction(4, 5) if chosen == greedy else 0)
            remaining.remove(chosen)
        paths.append({'sequence': list(permutation), 'p_fraction': str(p),
                      'p': float(p), 'weight': float(24 * p)})
    ps = [Fraction(x['p_fraction']) for x in paths]
    mean_w2 = sum((24 * p) ** 2 for p in ps) / 24
    return {
        'scope': 'ILLUSTRATIVE_EXACT_ARITHMETIC_NOT_EMPIRICAL_FINDING',
        'capacity': {
            'full_route_core_session_anchor': 48 + 240 + 240,
            'full_route_station_hours_55_70min': [528 * 55 / 60, 528 * 70 / 60],
            'stage1_only_core_session_anchor': 48 + 240,
            'stage1_only_station_hours_55_70min': [288 * 55 / 60, 288 * 70 / 60],
            'excluded': ['Level A', 'Level B', 'training', 'rehearsal', 'rework', 'administration'],
        },
        'ope_counterexample': {
            'behavior': 'Uniform over 24 permutations; 96 trajectories = four of each.',
            'target': '80% fixed greedy preference plus 20% uniform over remaining actions.',
            'probabilities_sum_fraction': str(sum(ps)),
            'max_path_probability': float(max(ps)),
            'max_trajectory_weight': float(24 * max(ps)),
            'mean_squared_weight': float(mean_w2),
            'balanced_96_weight_ESS': float(Fraction(96) / mean_w2),
            'warning': 'Not measured support, value or ESS of any SRP learned policy.',
            'paths': paths,
        },
        'joint_power_counterexample': {
            'hypothetical_independent_gates': 4,
            'each_pass_probability': 0.9,
            'joint_probability': float(Fraction(9, 10) ** 4),
            'warning': 'SRP gates are dependent; this is not its power calculation.',
        },
    }

def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path)
    args = parser.parse_args()
    text = json.dumps(checks(), ensure_ascii=False, indent=2) + '\n'
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(text, encoding='utf-8')
    else:
        print(text)
    return 0
if __name__ == '__main__':
    raise SystemExit(main())
