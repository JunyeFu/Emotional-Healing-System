"""Tests of this audit package's tools only; no repository regression is run."""
import copy
import sys
import unittest
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'tools'))
from audit_registry import analyse
from route_checks import evaluate_route
from planning_checks import checks

def row(tid, status='DONE', deps='', kind='FIXED', **extra):
    return dict(task_id=tid, status=status, depends_on=deps, kind=kind, **extra)

class RegistryTests(unittest.TestCase):
    def test_empty(self):
        self.assertFalse(analyse([])['ok'])
    def test_valid_dag(self):
        self.assertTrue(analyse([row('A'), row('B', 'READY', 'A')])['ok'])
    def test_unknown_dependency_does_not_crash(self):
        result = analyse([row('A', deps='MISSING')])
        self.assertIn('UNKNOWN_DEPENDENCY', [x['code'] for x in result['issues']])
    def test_duplicate(self):
        self.assertFalse(analyse([row('A'), row('A')])['ok'])
    def test_cycle(self):
        result = analyse([row('A', deps='B'), row('B', deps='A')])
        self.assertIn('DEPENDENCY_CYCLE', [x['code'] for x in result['issues']])
    def test_self_dependency(self):
        self.assertFalse(analyse([row('A', deps='A')])['ok'])
    def test_placeholder_reviewer(self):
        self.assertFalse(analyse([row('A', reviewer='待真实团队第二人复核')])['ok'])
    def test_empty_reviewer(self):
        self.assertFalse(analyse([row('A', reviewer='')])['ok'])
    def test_missing_review_columns_is_not_fake_verification(self):
        r = analyse([row('A')])
        self.assertTrue(r['ok'])
        self.assertIn('REVIEW_METADATA_NOT_PROVIDED', [x['code'] for x in r['issues']])
    def test_in_progress_dependency_checked(self):
        self.assertFalse(analyse([row('A', 'WAIT_DEP'), row('B', 'IN_PROGRESS', 'A')])['ok'])
    def test_template_not_done(self):
        self.assertFalse(analyse([row('B-01', kind='TEMPLATE')])['ok'])
    def test_template_not_ready(self):
        self.assertFalse(analyse([row('B-01', 'READY', kind='TEMPLATE')])['ok'])
    def test_stage3_bottleneck(self):
        r = analyse([row('E-06'), row('A-04', deps='E-06'), row('W-02', deps='A-04')], stage3_optional=True)
        self.assertTrue(r['paper_W02_requires_E06'])
        self.assertIn('OPTIONAL_STAGE3_HARD_DEPENDENCY', [x['code'] for x in r['issues']])
    def test_unknown_status(self):
        self.assertFalse(analyse([row('A', 'MAGIC_PASS')])['ok'])
    def test_missing_id(self):
        self.assertFalse(analyse([row('')])['ok'])

class RouteTests(unittest.TestCase):
    def setUp(self):
        self.receipt = {'human_approved': True, 'scope': 'NO_STAGE3',
                        'record_ref': 'SYNTHETIC_TEST_ONLY', 'source_commit': 'TEST_COMMIT',
                        'human_reviewer': 'SYNTHETIC_FIXTURE_NOT_A_PERSON', 'review_method': 'synthetic'}
    def test_stage1_metadata_path(self):
        r = evaluate_route('stage1_only', {'A-05','W-01'}, False, self.receipt)
        self.assertTrue(r['metadata_consistent'])
        self.assertFalse(r['authorization_to_run_study'])
        self.assertFalse(r['human_authenticity_verified'])
    def test_stage1_requires_results(self):
        self.assertFalse(evaluate_route('stage1_only', {'W-01'}, False, self.receipt)['metadata_consistent'])
    def test_scope_approval_missing(self):
        self.receipt['human_approved'] = False
        self.assertFalse(evaluate_route('stage1_only', {'W-01','A-05'}, False, self.receipt)['metadata_consistent'])
    def test_cannot_hide_stage3(self):
        self.assertFalse(evaluate_route('stage1_only', {'W-01','A-05'}, True, self.receipt)['metadata_consistent'])
    def test_stage3_requires_A04(self):
        self.receipt['scope'] = 'INCLUDE_STAGE3'
        self.assertFalse(evaluate_route('with_stage3', {'W-01','A-05'}, True, self.receipt)['metadata_consistent'])
    def test_stage3_metadata_path(self):
        self.receipt['scope'] = 'INCLUDE_STAGE3'
        self.assertTrue(evaluate_route('with_stage3', {'W-01','A-05','A-04'}, True, self.receipt)['metadata_consistent'])
    def test_non_boolean_stage3_is_invalid(self):
        self.assertFalse(evaluate_route('stage1_only', {'W-01','A-05'}, 'false', self.receipt)['metadata_consistent'])
    def test_unknown_route(self):
        self.assertFalse(evaluate_route('skip_all', set(), False, self.receipt)['metadata_consistent'])
    def test_empty_receipt_reference(self):
        self.receipt['record_ref'] = ''
        self.assertFalse(evaluate_route('stage1_only', {'W-01','A-05'}, False, self.receipt)['metadata_consistent'])

class ArithmeticTests(unittest.TestCase):
    def test_capacity(self):
        c = checks()['capacity']
        self.assertEqual(c['full_route_station_hours_55_70min'], [484, 616])
        self.assertEqual(c['stage1_only_station_hours_55_70min'], [264, 336])
    def test_path_probabilities(self):
        r = checks()['ope_counterexample']
        self.assertEqual(len(r['paths']), 24)
        self.assertEqual(r['probabilities_sum_fraction'], '1')
        self.assertAlmostEqual(r['max_path_probability'], .663)
        self.assertAlmostEqual(r['max_trajectory_weight'], 15.912)
    def test_ess(self):
        self.assertAlmostEqual(checks()['ope_counterexample']['balanced_96_weight_ESS'], 8.792445530799935)
    def test_joint_counterexample(self):
        self.assertAlmostEqual(checks()['joint_power_counterexample']['joint_probability'], .6561)


# Additional path/byte integrity tests use synthetic temporary files only.
import hashlib
import json
import tempfile
from inspect_replacement_plan import safe_relative
from verify_bundle import verify

class DeliveryIntegrityTests(unittest.TestCase):
    def test_safe_path(self):
        self.assertTrue(safe_relative('目录/文件.md'))
    def test_path_traversal(self):
        self.assertFalse(safe_relative('../outside.md'))
    def test_windows_absolute_path(self):
        self.assertFalse(safe_relative('C:\\data\\file.md'))
    def test_posix_absolute_path(self):
        self.assertFalse(safe_relative('/etc/passwd'))
    def test_good_manifest(self):
        with tempfile.TemporaryDirectory() as t:
            root = Path(t)
            (root / 'a.txt').write_bytes(b'abc')
            manifest = {'files':[{'path':'a.txt','bytes':3,'sha256':hashlib.sha256(b'abc').hexdigest()}]}
            (root / 'BUNDLE_MANIFEST.json').write_text(json.dumps(manifest))
            self.assertTrue(verify(root)['ok'])
    def test_changed_bytes(self):
        with tempfile.TemporaryDirectory() as t:
            root = Path(t)
            (root / 'a.txt').write_bytes(b'xyz')
            manifest = {'files':[{'path':'a.txt','bytes':3,'sha256':hashlib.sha256(b'abc').hexdigest()}]}
            (root / 'BUNDLE_MANIFEST.json').write_text(json.dumps(manifest))
            self.assertFalse(verify(root)['ok'])
    def test_extra_file(self):
        with tempfile.TemporaryDirectory() as t:
            root = Path(t)
            (root / 'extra.txt').write_text('x')
            (root / 'BUNDLE_MANIFEST.json').write_text(json.dumps({'files':[]}))
            self.assertFalse(verify(root)['ok'])
    def test_manifest_traversal(self):
        with tempfile.TemporaryDirectory() as t:
            root = Path(t)
            (root / 'BUNDLE_MANIFEST.json').write_text(json.dumps({'files':[{'path':'../outside'}]}))
            self.assertFalse(verify(root)['ok'])

if __name__ == '__main__':
    unittest.main()
