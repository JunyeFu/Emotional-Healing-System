# SRP × IJHCI 仓库审计与升级包

**固定仓库**：`JunyeFu/Emotional-Healing-System`  
**固定提交**：`145f7b20b5e2b3453235fb79090b982785b4c5a3`  
**日期**：2026-09-05  
**性质**：仓库级体系审计、重点文件静态复核与升级规划；非逐字节全仓复验，非正式研究准入或结果。

## 先读什么

| 文件 | 用途 |
|---|---|
| [总审计报告与升级裁定](reports/00_总审计报告与升级裁定.md) | 全局结论、现状、关键问题与推荐路线 |
| [24项问题与关闭标准](reports/01_问题清单与关闭判据.md) | 2 critical、16 major、6 minor；事实、风险与提案明确区分 |
| [58项逐包审计](reports/02_58项任务逐包审计.md) | 全部登记包的范围、状态、下一步和验收 |
| [目标架构与原始证据束](reports/03_目标架构与原始证据束.md) | 修复重建根、单一权威、设备、消息和真实集成 |
| [研究测量统计与可行性](reports/04_研究测量统计与可行性.md) | Gate、PF、联合功效、缺失和策略支持 |
| [任务重编排与四人协作](reports/05_任务重编排与四人协作.md) | 条件式A-06、准入分层、成员与外包接入 |
| [Agent辅助与证据治理](reports/06_Agent辅助开发与证据治理.md) | 权限、上下文、审查、MCP、真实签收与AI日志 |
| [论文与投稿系统](reports/07_论文与投稿系统.md) | 主张—数据—结果—表图—稿件的可复验链 |
| [逐文件变更与应用](reports/08_逐文件变更与应用手册.md) | 4份完整候选替换、1份新增提案与应用流程 |
| [覆盖与局限](reports/09_审计覆盖方法与局限.md) | 哪些全文读过、哪些仅目录或分段、哪些未复跑 |

## 机器清单与升级任务

[58项审计CSV](registers/58_task_audit.csv)、[原注册表审计提取](registers/task_registry_audit_extract.csv)、[问题CSV](registers/findings.csv)、[12项升级工作](registers/upgrade_backlog.csv)、[逐文件变更](registers/file_change_plan.csv)、[来源与读取深度](registers/source_coverage.csv)、[外部来源](registers/external_sources.csv)。

`upgrade_tasks/UP-01.md`至`UP-12.md`是逐条升级工作说明。状态全部为PROPOSED_NOT_APPROVED，通常挂到原包子交付，不默认净增12个顶层任务。

## 候选修改与模板

`proposed_replacements/`保留仓库相对路径，包含根README、在线架构、离线架构、MCP README的完整候选替换，以及新增执行补充提案。它们尚未部署，没有修改协议参数或历史签收。根目录[replacement_plan.json](replacement_plan.json)记录原Git blob和候选字节哈希。

`templates/`提供A-06草案、条件收尾规则、证据记录、原始证据束、AI运行记录、统计模拟规格、主张清单与外部资格表。空字段和PENDING都是真实待填状态，不能作为批准或结果使用。

## 工具及已完成验证

标准库Python工具位于`tools/`；需要Python3.10及以上。建议从本包根目录执行：

```text
python -m unittest discover -s tests -v
python tools/audit_registry.py registers/task_registry_audit_extract.csv --stage3-optional
python tools/planning_checks.py
python tools/verify_bundle.py
```

[单元测试记录](validation/audit_tool_unit_tests.txt)是本包工具的36项测试，不是仓库产品回归。[注册表复核](validation/audit_tool_registry_result.json)基于58项人工转录字段；它没有完整签收元数据，不会声称已验证真人签名。[规划算术](validation/planning_checks.json)为精确算术与反例，**不是实际OPE或正式功效结果**。

在真实工作区只读预检候选：

```text
python tools/inspect_replacement_plan.py --repo-root D:\Agent\03-SRP --plan replacement_plan.json
```

该命令先检查git status与HEAD、原blob和候选哈希；不会复制、删除、提交或push。若基线改变或工作区已有修改，会报告需要重新对齐并保留现有文件。该预检尚未在用户真实工作区执行。

## 使用边界

仓库已有构建、组件测试与真人签收来源被保留并逐范围解释，但本次没有完整克隆、运行Unity/TD/设备、重新执行仓库回归或启动参与者研究。未读素材/代码明确列入补审，不用“全仓通过”概括。

引用[Sxx]/[Exx]/[Hxx]分别指来源台账的仓库、外部及历史附件条目；台账含固定提交链接与读取深度。候选替换文件内链接以其未来仓库位置解析，不要求在本包内复制整仓库。

所有表格CSV为UTF-8 BOM；Markdown/JSON/Python为UTF-8。包内无参与者原始数据、密钥、字体文件或大型仓库资产。外部作者说明、许可与审批应按真正执行/提交时点复核。
