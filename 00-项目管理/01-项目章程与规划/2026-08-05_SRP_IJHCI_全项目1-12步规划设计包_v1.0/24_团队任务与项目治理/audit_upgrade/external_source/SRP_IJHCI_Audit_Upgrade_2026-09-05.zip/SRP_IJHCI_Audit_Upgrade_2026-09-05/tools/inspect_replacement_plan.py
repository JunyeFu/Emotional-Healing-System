"""Inspect candidate replacements against a clean, exact Git baseline. Never applies edits."""
from __future__ import annotations
import argparse
import hashlib
import json
import subprocess
from pathlib import Path, PurePosixPath
from typing import Any

def safe_relative(value: str) -> bool:
    p = PurePosixPath(value)
    return bool(value) and not p.is_absolute() and '..' not in p.parts and '\\' not in value and ':' not in value

def git(repo: Path, *args: str) -> str:
    result = subprocess.run(['git', '-C', str(repo), *args], capture_output=True, text=True,
                            encoding='utf-8', errors='replace', check=False)
    if result.returncode:
        raise RuntimeError(f'git {args[0]} failed: {result.stderr.strip()}')
    return result.stdout.strip()

def inspect(repo: Path, plan_path: Path) -> dict[str, Any]:
    errors: list[str] = []
    plan = json.loads(plan_path.read_text(encoding='utf-8'))
    # First repository command, in accordance with the project's working-tree rule.
    status = git(repo, 'status', '--short')
    head = git(repo, 'rev-parse', 'HEAD')
    if status:
        errors.append('DIRTY_WORKTREE_PRESERVE_EXISTING_CHANGES')
    if head != plan.get('expected_head'):
        errors.append('HEAD_CHANGED_REBASE_PLAN_REQUIRED')
    checks: list[dict[str, Any]] = []
    for operation in plan.get('operations', []):
        path = operation.get('repository_path', '')
        candidate = operation.get('candidate_path', '')
        if not safe_relative(path) or not safe_relative(candidate):
            errors.append('UNSAFE_RELATIVE_PATH')
            continue
        source = (plan_path.parent / candidate).resolve()
        if not source.is_relative_to(plan_path.parent.resolve()) or not source.is_file():
            errors.append('CANDIDATE_MISSING:' + candidate)
            continue
        digest = hashlib.sha256(source.read_bytes()).hexdigest()
        if digest != operation.get('candidate_byte_sha256'):
            errors.append('CANDIDATE_HASH_MISMATCH:' + candidate)
        target = repo / path
        action = operation.get('action')
        if action == 'ADD':
            if target.exists():
                errors.append('ADD_TARGET_ALREADY_EXISTS:' + path)
        elif action == 'REPLACE':
            try:
                blob = git(repo, 'rev-parse', f'HEAD:{path}')
                if blob != operation.get('expected_base_git_blob'):
                    errors.append('BASE_BLOB_CHANGED:' + path)
            except RuntimeError:
                errors.append('BASE_FILE_NOT_FOUND:' + path)
        else:
            errors.append('UNKNOWN_ACTION:' + str(action))
        checks.append({'path': path, 'action': action, 'candidate_sha256': digest})
    return {'preflight_consistent': not errors, 'actual_head': head,
            'worktree_status': status, 'errors': errors, 'operations_checked': checks,
            'applied': False, 'committed': False, 'pushed': False,
            'research_approval_verified': False,
            'next_step': 'Human review and approved scoped application only; this tool never applies.'}

def main() -> int:
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--repo-root', type=Path, required=True)
    p.add_argument('--plan', type=Path, required=True)
    args = p.parse_args()
    try:
        result = inspect(args.repo_root.resolve(), args.plan.resolve())
    except (OSError, ValueError, RuntimeError) as exc:
        result = {'preflight_consistent': False, 'applied': False, 'error': str(exc)}
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0 if result['preflight_consistent'] else 2
if __name__ == '__main__':
    raise SystemExit(main())
