"""Read-only structural audit. Metadata checks do not authenticate human evidence."""
from __future__ import annotations
import argparse
import csv
import json
from collections import Counter
from pathlib import Path
from typing import Any

VALID_STATUSES = {'READY', 'IN_PROGRESS', 'IN_REVIEW', 'DONE', 'WAIT_DEP',
                  'WAIT_DEP_EXTERNAL', 'BLOCKED_EXTERNAL'}
PLACEHOLDERS = ('待复核', '待真实', '待签', '未签署', 'pending', 'tbd', 'todo')

def analyse(rows: list[dict[str, Any]], *, stage3_optional: bool = False) -> dict[str, Any]:
    issues: list[dict[str, str]] = []
    def issue(code: str, message: str, severity: str = 'error') -> None:
        issues.append({'code': code, 'severity': severity, 'message': message})
    if not rows:
        issue('EMPTY_REGISTRY', 'No tasks were provided.')
    by_id: dict[str, dict[str, Any]] = {}
    for index, row in enumerate(rows, 1):
        tid = str(row.get('task_id') or '').strip()
        if not tid:
            issue('EMPTY_TASK_ID', f'Row {index} has no task_id.')
            continue
        if tid in by_id:
            issue('DUPLICATE_TASK_ID', tid)
            continue
        by_id[tid] = row
    graph: dict[str, set[str]] = {}
    for tid, row in by_id.items():
        status = str(row.get('status') or '')
        if status not in VALID_STATUSES:
            issue('INVALID_STATUS', f'{tid}: {status}')
        deps = {d.strip() for d in str(row.get('depends_on') or '').split('|') if d.strip()}
        graph[tid] = deps
        for dep in sorted(deps - by_id.keys()):
            issue('UNKNOWN_DEPENDENCY', f'{tid} -> {dep}')
        if tid in deps:
            issue('SELF_DEPENDENCY', tid)
        if row.get('kind') == 'TEMPLATE' and status in {'READY', 'DONE'}:
            issue('TEMPLATE_NOT_INSTANCE', f'{tid}: a template cannot be {status}.')
        if status in {'READY', 'IN_PROGRESS', 'IN_REVIEW'}:
            for dep in sorted(deps & by_id.keys()):
                if by_id[dep].get('status') != 'DONE':
                    issue('INCOMPLETE_DEPENDENCY', f'{tid} -> {dep}')
        if status == 'DONE' and 'reviewer' in row:
            reviewer = str(row.get('reviewer') or '').strip()
            if not reviewer:
                issue('REVIEWER_MISSING', tid)
            elif any(word in reviewer.casefold() for word in PLACEHOLDERS):
                issue('REVIEWER_PLACEHOLDER', f'{tid}: reconcile with actual signed scope.')
    # Unknown nodes are reported above, not dereferenced: no KeyError on bad input.
    colour = {tid: 0 for tid in graph}
    def visit(tid: str, trail: tuple[str, ...]) -> None:
        if colour[tid] == 1:
            issue('DEPENDENCY_CYCLE', ' -> '.join((*trail, tid)))
            return
        if colour[tid] == 2:
            return
        colour[tid] = 1
        for dep in sorted(graph[tid] & graph.keys()):
            visit(dep, (*trail, tid))
        colour[tid] = 2
    for tid in graph:
        visit(tid, ())
    def ancestors(tid: str) -> set[str]:
        seen: set[str] = set()
        pending = list(graph.get(tid, set()) & graph.keys())
        while pending:
            dep = pending.pop()
            if dep not in seen:
                seen.add(dep)
                pending.extend(graph.get(dep, set()) & graph.keys() - seen)
        return seen
    paper_requires_stage3 = 'E-06' in ancestors('W-02')
    if stage3_optional and paper_requires_stage3:
        issue('OPTIONAL_STAGE3_HARD_DEPENDENCY',
              'W-02 has E-06 as an unconditional ancestor.', 'warning')
    if rows and not any('reviewer' in r for r in rows):
        issue('REVIEW_METADATA_NOT_PROVIDED',
              'This extract does not contain reviewer fields; no sign-off verdict is possible.', 'info')
    return {
        'scope': 'STATIC_REGISTRY_METADATA_ONLY; no runtime, human-signature or external-gate verification',
        'ok': not any(x['severity'] == 'error' for x in issues),
        'entry_count': len(rows), 'unique_ids': len(by_id),
        'statuses': dict(Counter(str(r.get('status')) for r in rows)),
        'paper_W02_requires_E06': paper_requires_stage3,
        'A03_device_ancestors': sorted(ancestors('A-03') & {'D-01', 'D-02'}),
        'issues': issues,
    }

def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('registry', type=Path)
    parser.add_argument('--stage3-optional', action='store_true')
    parser.add_argument('--output', type=Path)
    args = parser.parse_args()
    if args.output and args.output.resolve() == args.registry.resolve():
        print(json.dumps({'ok': False, 'error': 'OUTPUT_MUST_NOT_OVERWRITE_REGISTRY'}))
        return 1
    try:
        with args.registry.open(encoding='utf-8-sig', newline='') as handle:
            result = analyse(list(csv.DictReader(handle)), stage3_optional=args.stage3_optional)
    except (OSError, UnicodeError, csv.Error) as exc:
        result = {'ok': False, 'scope': 'INPUT_ERROR', 'error': str(exc)}
    text = json.dumps(result, ensure_ascii=False, indent=2)
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(text + '\n', encoding='utf-8')
    else:
        print(text)
    return 0 if result['ok'] else 1

if __name__ == '__main__':
    raise SystemExit(main())
