"""Verify this delivery's byte hashes and file census. Not scientific validation."""
from __future__ import annotations
import argparse
import hashlib
import json
from pathlib import Path, PurePosixPath

def verify(root: Path) -> dict:
    manifest_path = root / 'BUNDLE_MANIFEST.json'
    errors: list[str] = []
    try:
        manifest = json.loads(manifest_path.read_text(encoding='utf-8'))
    except (OSError, ValueError) as exc:
        return {'ok': False, 'errors': ['MANIFEST_UNREADABLE:' + str(exc)]}
    seen: set[str] = set()
    for item in manifest.get('files', []):
        relative = item.get('path', '')
        p = PurePosixPath(relative)
        if not relative or p.is_absolute() or '..' in p.parts or '\\' in relative or ':' in relative:
            errors.append('UNSAFE_PATH:' + relative)
            continue
        if relative in seen:
            errors.append('DUPLICATE_PATH:' + relative)
            continue
        seen.add(relative)
        path = (root / relative).resolve()
        if not path.is_relative_to(root.resolve()) or not path.is_file():
            errors.append('MISSING_OR_OUTSIDE_FILE:' + relative)
            continue
        content = path.read_bytes()
        if len(content) != item.get('bytes') or hashlib.sha256(content).hexdigest() != item.get('sha256'):
            errors.append('HASH_OR_SIZE_MISMATCH:' + relative)
    actual = {p.relative_to(root).as_posix() for p in root.rglob('*')
              if p.is_file() and p.name != 'BUNDLE_MANIFEST.json'
              and '__pycache__' not in p.parts and p.suffix != '.pyc'}
    if actual != seen:
        errors.append('FILE_CENSUS_MISMATCH:extra=' + repr(sorted(actual - seen))
                      + ';missing=' + repr(sorted(seen - actual)))
    return {'ok': not errors, 'file_count_excluding_manifest': len(seen), 'errors': errors,
            'scope': 'DELIVERY_BYTE_INTEGRITY_ONLY; not execution, scientific or human approval.'}

def main() -> int:
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--root', type=Path, default=Path(__file__).resolve().parents[1])
    args = p.parse_args()
    result = verify(args.root.resolve())
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0 if result['ok'] else 1
if __name__ == '__main__':
    raise SystemExit(main())
