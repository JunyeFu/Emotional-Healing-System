"""Proposed route-metadata checks, never authorization to conduct a study."""
from __future__ import annotations
from typing import Any

def evaluate_route(route: str, completed: set[str], stage3_started: bool,
                   receipt: dict[str, Any]) -> dict[str, Any]:
    errors: list[str] = []
    if route not in {'stage1_only', 'with_stage3'}:
        errors.append('UNKNOWN_ROUTE')
    if type(stage3_started) is not bool:
        errors.append('STAGE3_STARTED_MUST_BE_BOOLEAN')
    expected_scope = 'NO_STAGE3' if route == 'stage1_only' else 'INCLUDE_STAGE3'
    required = {'A-05', 'W-01'}
    if route == 'with_stage3':
        required.add('A-04')
    if not required <= completed:
        errors.append('MISSING_RESULTS:' + ','.join(sorted(required - completed)))
    if receipt.get('human_approved') is not True:
        errors.append('SCOPE_NOT_APPROVED')
    if receipt.get('scope') != expected_scope:
        errors.append('SCOPE_MISMATCH')
    for key in ('record_ref', 'source_commit', 'human_reviewer', 'review_method'):
        if not isinstance(receipt.get(key), str) or not receipt[key].strip():
            errors.append('MISSING_RECEIPT_FIELD:' + key)
    if route == 'stage1_only' and stage3_started is True:
        errors.append('CANNOT_HIDE_STARTED_STAGE3')
    if route == 'with_stage3' and stage3_started is False:
        errors.append('STAGE3_NOT_STARTED')
    return {'metadata_consistent': not errors, 'errors': errors,
            'human_authenticity_verified': False,
            'authorization_to_run_study': False,
            'scope': 'PROPOSAL_METADATA_CHECK_ONLY'}
